Mumble used to use a full BSD-style license in
each file.

We now use a shorter, generic license header
(see LICENSE.header in the root of the source tree.)

However, some files still have the full license text.
This is because we haven't gotten permission from all
authors in those files to only use the shorter license
header.

The license text in LICENSE.txt is a license to be shown
in Mumble's third party licenses screen to live up to the
BSD license requirement of reproducing the copyright notices
from those files.
